plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.swara.myofflineai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.swara.myofflineai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
