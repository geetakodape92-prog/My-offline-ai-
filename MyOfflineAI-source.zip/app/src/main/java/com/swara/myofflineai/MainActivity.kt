package com.swara.myofflineai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,16,20)
        window.navigationBarColor = Color.rgb(16,16,20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
            setBackgroundColor(Color.rgb(16,16,20))
        }
        val title = TextView(this).apply {
            text = "My Offline AI"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "Your private AI workspace"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            addView(messages)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        input = EditText(this).apply {
            hint = "Type a message..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setBackgroundColor(Color.rgb(38,38,46))
            setPadding(18, 12, 18, 12)
        }
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener {
                val prompt = input.text.toString().trim()
                if (prompt.isNotEmpty()) {
                    addMessage("You: $prompt")
                    addMessage("AI: Model connection will be added in the next step. This starter app is currently an interface only.")
                    input.text.clear()
                }
            }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(scroll)
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(send)
        root.addView(bottom)
        setContentView(root)
        addMessage("AI: Welcome! Your My Offline AI app interface is ready.")
    }

    private fun addMessage(text: String) {
        val view = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(38,38,46))
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 12, 0, 0)
        messages.addView(view, params)
    }
}
